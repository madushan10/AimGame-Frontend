import React from 'react'

export default function HeaderNotification() {
    return (
        <div>
            <img src='/icons/notification.svg' className='h-5' />
        </div>
    )
}
