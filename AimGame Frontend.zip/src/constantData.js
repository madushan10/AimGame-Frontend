export const menuData = [
    {
        title: "Home",
        href: "/dashboard"
    },
    {
        title: "Opportunity",
        href: "/opportunities"
    },
    // {
    //     title: "Account",
    //     href: "/account"
    // },
    {
        title: "Presales",
        href: "/presales"
    },
    {
        title: "Partners",
        href: "/partners"
    },
    // {
    //     title: "Resources",
    //     href: "/resources"
    // },
    {
        title: "Clients",
        href: "/clients"
    },
    {
        title: "Workspaces",
        href: "/workspaces"
    },
    {
        title: "Team",
        href: "/teams"
    },
    {
        title: "Tasks",
        href: "/tasks"
    },
    // {
    //     title: "Subscription",
    //     href: "/subscription"
    // },
]